# Mastercard Connect - MCC v2
## Creator: Deepak Shinde <deepak.shinde@mastercard.com>
### MCC v2 to have more generic components with structural and updated UI + existing feature and functionality

0. mcc.min.css IS NOW b2b.css
1. Caret and Chevron changes
	- Navigation, Export Button, Filter etc. should have Chevron
	- Sorting options to have Caret
2. MIM integration
3. LOGO - Mastercard logo + Connect to be single SVG.

Changelog: DEV 07/09/2017 - Michael Torpea
1. Moved placedment of 'View' filter to front.

Changelog: DEV 08/09/2017 - Deepak Shinde
1. Calendar top/ bottom arrow fix
2. Pagination overlapping fix
3. Bug fixes for MIM

Changelog: DEV 08/09/2017 - Deepak Shinde
1. Updated CARET icons
2. Pagination input can also be a NUMBER, if required.

Changelog: DEV 09/20/2017 - Rahul Chavan
1. Updated Help guide
2. All HTML elements fix
3. helpme.css fix

Changelog: DEV 09/20/2017 - Deepak Shinde
1. Updated all Markup files to use b2b.min.css and mcc.min.css
2. All MIM Files to have the IE9 specific CSS block. This would be needed for all files - where IE9 support is required.
3. Updated SCSS structure: b2b.scss = Bootstrap.scss + custom.scss and ie9 = only custom.scss

Changelog: DEV 09/22/2017 - Rahul Chavan
1. Updated Help guide HTML

Changelog: DEV 09/26/2017 - Rahul Chavan
1. Updated System Health All HTML and SCSS/CSS files.
2. Updated Sprite icon.

Changelog: DEV 09/25/2017 - Deepak Shinde
1. Updated SCSS for generic components like Report Cards, Bundled Cards etc.

Changelog: DEV 09/25/2017 - Deepak Shinde
1. Updated HTML and CSS files for MIM - removed inline CSS/ using existing CSS classes etc.
2. Updated Sprite icons.

Changelog: DEV 09/26/2017 - Rahul Chavan
1. Updated HTML for System Health Application

Changelog: DEV 09/26/2017 - Deepak Shinde
1. Updated ALL HTML and CSS files for MIM - Fixed Mobile issues, redundant Markup, Modals etc.
2. Updated Sprite icons - AI + SPRITE.

Changelog: DEV 09/27/2017 - Deepak Shinde
1. Updated TABS and STEPPED NAVIGATION for latest markup/ css
2. Updated Sprite icons - AI + SPRITE.

Changelog: DEV 09/28/2017 - Deepak Shinde
1. Updated BRAND COLORS and LOADING GRAPHICS

Changelog: DEV 09/29/2017 - Rahul Chavan
1. Updated HTML for System Health Application User page and CSS

Changelog: DEV 09/28/2017 - Michael Torpea
1. Changed User dashboard to have the drop down view change.
2. Updated replace user (single)
3. Created replace user (multiple)

Changelog: DEV 10/04/2017 - Deepak Shinde
1. Added NEW icons as FILE - variants and IMAGE - variants

Changelog: DEV 10/03/2017 - Rahul Chavan
1. Updated Help guide HTML and CSS

Changelog: DEV 10/04/2017 - Rahul Chavan
1. Updated Help guide HTML with file and image icons

Changelog: DEV 10/05/2017 - Rahul Chavan
1. Updated HTML for Store Plus pages and CSS

Changelog: DEV 10/04/2017 - Deepak Shinde
1. iPad/ Data grid specific CSS fixes

Changelog: DEV 10/06/2017 - Rahul Chavan
1. Updated HTML for Store Plus pages and CSS

Changelog: DEV 10/06/2017 - Deepak Shinde
1. iPad/ Landscape Dropdown/ Select min-width updated

Changelog: DEV 10/06/2017 - Rahul Chavan
1. Revert back changes for the "css-dev-29082017"

Changelog: DEV 10/13/2017 - Rahul Chavan
1. MIM fix for Mobile issue.

Changelog: DEV 10/30/2017 - Deepak Shinde
1. B2B and associated applications CSS files separated for MIM/ CCM, Health Watch and MDES etc.
2. Apart from MCC, other projects needs to add their projects specific CSS file along with the B2B CSS, now onwards.
3. Refer to MIM/CCM, HealthWatch, MDES etc. pages

Changelog: DEV 10/30/2017 - Deepak Shinde
1. Deleted redundent TEMP files

Changelog: DEV 10/30/2017 - Deepak Shinde
1. Added fresh generated /styles/CSS files

Changelog: DEV 10/31/2017 - Rahul Chavan
1. MDES Master branch pull and code merge.
2. Completed MDES HTML and CSS pages.

Changelog: DEV 10/31/2017 - Rahul Chavan
1. Completed merged changes for the MDES.

Changelog: DEV 11/01/2017 - Rahul Chavan
1. Modified MDES HTML pages.

Changelog: DEV 11/01/2017 - Rahul Chavan
1. Modified MDES HTML and CSS pages.

Changelog: DEV 11/01/2017 - Rahul Chavan
1. Modified index.html page.
Changelog: DEV 11/02/2017 - Rahul Chavan
1. CCM defects are fixed.

Changelog: DEV 11/03/2017 - Rahul Chavan
1. Completed Store Plus additional HTML page.

Changelog: DEV 11/03/2017 - Rahul Chavan
1. Store Plus HTML and CSS changes.

Changelog: DEV 11/03/2017 - Deepak Shinde 
1. Removed duplicate and not-required IDs from markup
2. Added comment about using CSS files.

Changelog: DEV 11/06/2017 - Rahul Chavan
1. System Health specific CSS added.

Changelog: DEV 11/06/2017 - Rahul Chavan
1. Modified System Health HTML pages.

Changelog: DEV 11/06/2017 - Rahul Chavan
1. Completed additional HTML changes for MDES application.

Changelog: DEV 11/08/2017 - Rahul Chavan
1. Fixed defect changes for System Health application.
Changelog: DEV 11/08/2017 - Rahul Chavan
1.	Completed addtional changes for System Health application.

Changelog: DEV 11/08/2017 - Rahul Chavan
1.	Added icons CSS in _icon.scss module.
Changelog: DEV 11/10/2017 - Rahul Chavan
1.	Modified minor changes in System Health application.

Changelog: DEV 11/10/2017 - Rahul Chavan
1.	Accordion funcnality changes in System Health application.

Changelog: DEV 11/15/2017 - Rahul Chavan
1.	Change request for System Health application.

Changelog: DEV 11/15/2017 - Rahul Chavan
1.	Added Watch icon for input in System Health application.

Changelog: DEV 11/16/2017 - Rahul Chavan
1.	Completed Custom Multi-select dropdown funcationality.

Changelog: DEV 11/17/2017 - Rahul Chavan
1.	Completed final changes for the System Health.

Changelog: DEV 11/21/2017 - Rahul Chavan
1.	Modified changes for multi-select dropdown.

Changelog: DEV 11/21/2017 - Rahul Chavan
1.	Modified HTML and CSS changes for the System Health.

Changelog: DEV 11/22/2017 - Rahul Chavan
1.	Modified HTML changes for the MCC Support page.

Changelog: DEV 11/22/2017 - Rahul Chavan
1.	Removed unwanted font icons for the System Health application.

Changelog: DEV 11/23/2017 - Rahul Chavan
1.	Resolved Font issue for the select dropdown in System Health application.

Changelog: DEV 11/27/2017 - Rahul Chavan
1.	Modified class for Modal Popup to get working functionality at Production end in System Health application.

Changelog: DEV 11/29/2017 - Rahul Chavan
Resolved Item Cards two lines heading text overflow functionality for Store Plus.

Changelog: DEV 11/30/2017 - Rahul Chavan
Removed store card specific class in My Apps for Store Plus.

Changelog: DEV 11/30/2017 - Rahul Chavan
1.	Remove highlight color for accordion in System Health application.

Changelog: DEV 12/05/2017 - Rahul Chavan
1.	Added CSS for Caledar Picker in System Health application.
Changelog: DEV 12/06/2017 - Rahul Chavan
1.	Revert back the accordion title text color for System Health application.

Changelog: DEV 12/06/2017 - Rahul Chavan
1.	Created HTML page as per the updated invision design for Store Plus application.

Changelog: DEV 12/11/2017 - Rahul Chavan
1.	Completed story for Store Plus application.

Changelog: DEV 12/15/2017 - Rahul Chavan
1.	Completed CSS changes for Datepicker.



Changelog: DEV 01/09/2018 - Rahul Chavan
1.	Modified Angular 4 Datepicker Component code changes to match datepicker look and feel as per the creatives.

Changelog: DEV 01/10/2018 - Rahul Chavan
1.	Completed fixes of Step Navigation in Firefox browser.

Changelog: DEV 01/10/2018 - Rahul Chavan
1.	Completed Angular 4 Datepicker Component with datepicker related codebase.

Changelog: DEV 01/12/2018 - Rahul Chavan
1.	Completed My Comapny signle serarch select (auto-search) mockup JSON.

Changelog: DEV 01/15/2018 - Rahul Chavan
1.	Completed jQuery UI Datepicker for Store Plus using Angular 1.x.


Changelog: DEV 01/17/2018 - Rahul Chavan
1.	Resolved datepicker conflict and removed bootstrap datepicker plugin from vendor js file.
Changelog: DEV 01/18/2018 - Rahul Chavan
1.	Modified Angular 4 code from Datepicker Component.

Changelog: DEV 01/19/2018 - Rahul Chavan
1.	Modified CSS changes for story S363582: System Health UI/UX- font change.

Changelog: DEV 01/23/2018 - Rahul Chavan
1.	Modified changes on jquery UI datepicker component for Story S363582: System Health UI/UX- font change.
Changelog: DEV 01/25/2018 - Rahul Chavan
1.	Modified CSS changes for Store Plus Datepicker Component.

Changelog: DEV 01/25/2018 - Rahul Chavan
1.	Modified Javascript changes for Store Plus Datepicker Component.

Changelog: DEV 01/25/2018 - Rahul Chavan
1.	Completed MCC Warriors story 5373807 AMS account billing multiple reposts for Store plus application.


Changelog: DEV 02/07/2018 - Rahul Chavan
1.	Updated CCM HTML/CSS pages with Beautify.

Changelog: DEV 02/09/2018 - Rahul Chavan
1.	Created Store Plus Home page and modified other related page beautify.

Changelog: DEV 02/13/2018 - Deepak Shinde
1.	Updated SPRITE AI and SVG for Checkmark active and disabled states

Changelog: DEV 02/15/2018 - Rahul Chavan
1.	MCC Warriors Defect DE77060: iOS device Checkbox issue fixed for Entire MCC Application.

Changelog: DEV 02/15/2018 - Rahul Chavan
1.	Modified CSS for iOS device Checkbox issue for MCC Application.

Changelog: DEV 02/23/2018 - Deepak Shinde
1.	Updated SPRITE AI and SVG for Active and Submitted icons

Changelog: DEV 02/23/2018 - Deepak Shinde
1.	Updated CSS and HELP/index.html for Active and Submitted icons

Changelog: DEV 03/01/2018 - Rahul Chavan
1.	Updated CSS, HTML and Images as per the latest code.

Changelog: DEV 03/01/2018 - Rahul Chavan
1.	Updated CSS for Datepicker component.

Changelog: DEV 03/23/2018 - Rahul Chavan
1.	Updated CSS for alert content message.

Changelog: DEV 04/02/2018 - Rahul Chavan
1.	Updated CSS for Datepicker readonly requirement.

Changelog: DEV 04/02/2018 - Michael Torpea
1.  Created Problem reported page - created 'carousel' effect
2.  Created .disabled class for coloring
3.  Updated index & readme files
4.  Created CSS for pointer on hover over &lt; and &gt; in problem reported

Changelog: DEV 04/16/2018 - Rahul Chavan
1.	Updated CSS for Store Plus Component.

Changelog: DEV 04/05/2018 - Michael Torpea
1.  Created 'Find a contact' overlay
2.  Created 'Find a contact results' page
3.  Updated CSS to accomodate new pages

Changelog: DEV 04/05/2018 - Deepak Shinde
1.	Updated SPRITE SVG for some additional icons = ESA

Changelog: DEV 04/17/2018 - Rahul Chavan
1.	Updated CSS for Store Plus Component.

Changelog: DEV 04/19/2018 - Deepak Shinde
1.	Updated SPRITE SVG for Security lock - MDES

Changelog: DEV 04/26/2018 - Rahul Chavan
1.	MCC Warriors story S442318: UI/UX for My Items - Toggle between list and card view(Completed Mockup HTML).

Changelog: DEV 05/02/2018 - Rahul Chavan
1.	Updated CSS for Store Plus Sprotlight Component.
2.	Updated CSS for MyItems Component.

Changelog: DEV 05/03/2018 - Rahul Chavan
1.	MCC Warriors story S442318: UI/UX for My Items - Toggle between list and card view(Completed UI Development).

Changelog: DEV 05/08/2018 - Rahul Chavan
1.	MCC Warriors story S442318: UI/UX for My Items - Toggle between list and card view(CSS Update).

Changelog: DEV 05/11/2018 - Rahul Chavan
1.	My Items - Toggle between list and card view(HTML and CSS Update) as per updated requirement.

Changelog: DEV 05/14/2018 - Rahul Chavan
1.	My Items - Toggle between list and card view(HTML and CSS Update) as per updated requirement.

Changelog: DEV 05/16/2018 - Rahul Chavan
1.	My Items - Toggle between list and card view(HTML and CSS Update) as per updated requirement.

Changelog: DEV 05/21/2018 - Rahul Chavan
1.	My Items additional scenario CSS fixes.

Changelog: DEV 05/21/2018 - Rahul Chavan
1.	Completed story about UX for view case details and support page.

Changelog: DEV 05/22/2018 - Rahul Chavan
1.	MCC Warriors story S443733: UX changes for closed cases(Completed UI Development).

Changelog: DEV 05/22/2018 - Rahul Chavan
1.	Modified CSS file name for Case support application.

Changelog: DEV 05/31/2018 - Michael Torpea
1.	Created global history HTML
2.  Created relevant CSS in ccm.scss

Changelog: DEV 06/13/2018 - Deepak Shinde
1.	Updated SPRITE SVG for Error STEP - MDES

Changelog: DEV 06/18/2018 - Rupali palshikar
1.	Updated Assetkit , help-> index.html and css files for step navigation with status.
Changelog: DEV 09/17/2018 - Rupali palshikar
1. MCC Warrios story S530425:Added new page "Connect new case"