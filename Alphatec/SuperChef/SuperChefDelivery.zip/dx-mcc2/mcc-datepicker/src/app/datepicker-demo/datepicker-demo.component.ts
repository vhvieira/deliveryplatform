import { Component, OnInit } from '@angular/core';
import { DpOptions } from '../common/directives/datepicker/interfaces/index';

@Component({
  selector: 'b2b-ccm-datepicker-demo',
  templateUrl: './datepicker-demo.component.html',
  styleUrls: []
})
export class DatepickerDemoComponent implements OnInit {

  dateConfig: DpOptions = {
    firstDayOfWeek: 'su',
    showTodayBtn: false,
    dateFormat: 'mmm dd, yyyy',
    disableInput: true
  };
  singleDateOptions: DpOptions;
  fromDateOptions: DpOptions;
  toDateOptions: DpOptions;

  disableUntilDt: Date;
  todayDate = new Date();
  singleDateEle: any;
  toDateEle: any;
  fromDateEle: any;
  singleDate: Object = {};
  filterICAListApiFailure = false;
  filterICASourcesApiFailure = false;
  
  constructor() { }

  ngOnInit() {
  }

  setDateRange(event: any, dateType: string) {
    if (dateType === 'modified_from') {

        let disableUntilYear = event.date['year'];
        let disableUntilMonth = event.date['month'];
        let disableUntilDay = event.date['day'];

        if (event.date['day'] > 1) {
            disableUntilDay = disableUntilDay - 1;
        } else if (event.date['day'] === 1) {
            disableUntilYear = (event.date['month'] === 1) ? disableUntilYear - 1 : disableUntilYear;
            disableUntilMonth = (event.date['month'] === 1) ? 12 : disableUntilMonth - 1;

            const tempDate = new Date(disableUntilYear, disableUntilMonth, 0);
            disableUntilDay = tempDate.getDate();
        }

        this.toDateOptions = {
            firstDayOfWeek: 'su',
            showTodayBtn: false,
            dateFormat: 'mmm dd, yyyy',
            disableUntil: {
                year: disableUntilYear,
                month: disableUntilMonth,
                day: disableUntilDay
            },
            disableSince: { year: this.todayDate.getFullYear(), month: this.todayDate.getMonth() + 1,
                day: this.todayDate.getDate() + 1 }
        };
    } else if (dateType === 'modified_to') {
        this.fromDateOptions = {
            firstDayOfWeek: 'su',
            showTodayBtn: false,
            dateFormat: 'mmm dd, yyyy',
            disableUntil: { year: this.disableUntilDt.getFullYear(), month: this.disableUntilDt.getMonth() + 1,
                day: this.disableUntilDt.getDate() },
            disableSince: { year: event.date['year'], month: event.date['month'],
                day: event.date['day'] + 1 }
        };
    }
}

}
