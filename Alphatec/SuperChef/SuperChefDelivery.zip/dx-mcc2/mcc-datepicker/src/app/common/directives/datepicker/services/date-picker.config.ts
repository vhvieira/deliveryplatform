import { Injectable } from '@angular/core';
import { DpOptions } from '../interfaces/options.interface';
import { DayLabels } from '../interfaces/day-labels.interface';
import { MonthLabels } from '../interfaces/month-labels.interface';
import { IDate } from '../interfaces/date.interface';
import { MarkedDates } from '../interfaces/marked-dates.interface';
import { DateRange } from '../interfaces/date-range.interface';
import { MarkedDate } from '../interfaces/marked-date.interface';
import { Year } from '../enums/year.enum';

@Injectable()
export class DatePickerConfig implements DpOptions {
    dayLabels: DayLabels = {su: 'Sun', mo: 'Mon', tu: 'Tue', we: 'Wed', th: 'Thu', fr: 'Fri', sa: 'Sat'};
    monthLabels: MonthLabels = {1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'May', 6: 'Jun', 7: 'Jul', 8: 'Aug', 9: 'Sep',
        10: 'Oct', 11: 'Nov', 12: 'Dec'};
    monthFullLabels: MonthLabels = {1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May', 6: 'June', 7: 'July',
        8: 'August', 9: 'September', 10: 'October', 11: 'November', 12: 'December'};
    dateFormat = 'mm/dd/yyyy';
    showTodayBtn = true;
    todayBtnTxt = 'Today';
    showNxtPrvDtOnCurrMon = false;
    firstDayOfWeek = 'su';
    satHighlight = true;
    sunHighlight = true;
    highlightDates = <Array<IDate>> [];
    markCurrentDay = true;
    markCurrentMonth = true;
    markCurrentYear = true;
    monthSelector = true;
    yearSelector = true;
    disableHeaderButtons = true;
    showWeekNumbers = false;
    selectorHeight = '280px';
    selectorWidth = '275px';
    disableUntil = <IDate> {year: 0, month: 0, day: 0};
    disableSince = <IDate> {year: 0, month: 0, day: 0};
    disableDates = <Array<IDate>> [];
    enableDates = <Array<IDate>> [];
    markDates = <Array<MarkedDates>> [];
    markWeekends = <MarkedDate> {};
    disableDateRanges = <Array<DateRange>> [];
    disableWeekends = false;
    alignSelectorRight = false;
    openSelectorTopOfInput = false;
    closeSelectorOnDateSelect = true;
    minYear = <number> Year.min;
    maxYear = <number> Year.max;
    showSelectorArrow = true;
    ariaLabelPrevMonth = 'Previous Month';
    ariaLabelNextMonth = 'Next Month';
    ariaLabelPrevYear = 'Previous Year';
    ariaLabelNextYear = 'Next Year';
    alignBottom = true;
    alignRight = false;
    alignTop = false;
    alignLeft = false;
    disableInput = false;
}
