export interface Weekday {
    number: number;
    weekday: string;
}
