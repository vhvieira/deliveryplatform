export enum MonthId {prev = 1, curr = 2, next = 3}
