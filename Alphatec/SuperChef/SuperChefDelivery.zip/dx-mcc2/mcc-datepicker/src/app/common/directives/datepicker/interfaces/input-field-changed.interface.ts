export interface InputFieldChanged {
    value: string;
    dateFormat: string;
    valid: boolean;
}
