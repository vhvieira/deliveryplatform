export interface Month {
    monthTxt: string;
    monthNbr: number;
    year: number;
}
