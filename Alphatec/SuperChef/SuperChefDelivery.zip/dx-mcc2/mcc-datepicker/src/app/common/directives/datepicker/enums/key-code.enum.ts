export enum KeyCode {enter = 13, esc = 27, space = 32, leftArrow = 37, rightArrow = 39}
