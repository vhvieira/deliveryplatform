import { CalendarDay } from './calendar-day.interface';

export interface Week {
    week: Array<CalendarDay>;
    weekNbr: number;
}

