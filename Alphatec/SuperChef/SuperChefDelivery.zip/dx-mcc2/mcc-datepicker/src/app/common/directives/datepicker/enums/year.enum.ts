export enum Year {min = 1100, max = 9100}
