export interface MonthLabels {
    [month: number]: string;
}
