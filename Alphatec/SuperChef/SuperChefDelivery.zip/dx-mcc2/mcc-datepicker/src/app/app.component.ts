
import { Component, EventEmitter } from '@angular/core';

/**
 * Root Component for mcc-datepicker
 */
@Component({
    selector: 'mcc-datepicker-root',
    templateUrl: './app.component.html'
})
export class AppComponent {}
